import { Mail, Phone, Briefcase, Zap, Lightbulb, Cpu, Wrench, ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-slate-900">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="font-bold text-slate-900 text-sm">Zypher Enterprise</p>
              <p className="text-xs text-slate-500">Innovation & Technology</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-8 text-sm font-medium">
            <a href="#about" className="text-slate-600 hover:text-blue-600 transition-colors">
              About
            </a>
            <a href="#expertise" className="text-slate-600 hover:text-blue-600 transition-colors">
              Expertise
            </a>
            <a href="#contact" className="text-slate-600 hover:text-blue-600 transition-colors">
              Contact
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="about" className="px-6 py-16 md:py-24 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-5 gap-12 items-center">
          <div className="md:col-span-2 flex justify-center md:justify-start">
            <div className="relative">
              <div className="absolute inset-0 bg-blue-600 rounded-2xl blur-2xl opacity-20"></div>
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-boph7vTExWGLQZJdb7bTMG1D4e1vgi.png"
                alt="Engr Hamid Mehmood Afridi"
                className="relative w-64 h-64 md:w-72 md:h-72 rounded-2xl object-cover shadow-2xl border-4 border-white"
              />
            </div>
          </div>

          {/* Profile Info */}
          <div className="md:col-span-3 space-y-8">
            <div className="space-y-4">
              <div className="inline-block">
                <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                  MANAGING DIRECTOR
                </span>
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-slate-900 text-balance leading-tight">
                Engr Hamid Mehmood Afridi
              </h1>
              <p className="text-2xl font-semibold text-slate-700">Mechatronics Engineer</p>
              <p className="text-lg text-slate-600">
                Leading innovation in sustainable technology and advanced research
              </p>
            </div>

            <div className="prose prose-sm max-w-none">
              <p className="text-base text-slate-700 leading-relaxed">
                Pioneering transformative solutions at the intersection of technology and sustainability. With deep
                expertise in electric vehicles, STEM education, artificial intelligence, and research & development, I
                drive Zypher Enterprise's mission to innovate and create lasting impact through cutting-edge technology.
              </p>
            </div>

            {/* CTA Button */}
            <div className="flex gap-4 pt-4">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Get in Touch
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section id="expertise" className="px-6 py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Areas of Expertise</h2>
            <p className="text-lg text-slate-600">Specialized knowledge across key technology domains</p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-8 border border-slate-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Electric Vehicles</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Next-generation EV solutions and sustainable mobility technologies
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 border border-slate-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Lightbulb className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">STEM Education</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Innovative educational technology and transformative learning solutions
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 border border-slate-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Cpu className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">AI Projects</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Artificial intelligence and machine learning applications and research
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 border border-slate-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Wrench className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">R&D Solutions</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Advanced research and development initiatives and innovation
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="px-6 py-20 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-slate-900 mb-4">Let's Connect</h2>
              <p className="text-lg text-slate-600">
                Open to discussing business opportunities, collaborations, and innovative projects. Reach out anytime.
              </p>
            </div>

            <div className="space-y-6">
              {/* Email */}
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-1">Email</p>
                  <a
                    href="mailto:hamid@zypherenterprise.com"
                    className="text-lg font-semibold text-slate-900 hover:text-blue-600 transition-colors"
                  >
                    hamid@zypherenterprise.com
                  </a>
                </div>
              </div>

              {/* Phone */}
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-1">Phone</p>
                  <a
                    href="tel:+923367239339"
                    className="text-lg font-semibold text-slate-900 hover:text-blue-600 transition-colors"
                  >
                    +92 336 7239339
                  </a>
                </div>
              </div>

              {/* Company */}
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-1">Company</p>
                  <p className="text-lg font-semibold text-slate-900">Zypher Enterprise</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-10 text-white space-y-6">
            <div>
              <h3 className="text-2xl font-bold mb-2">Zypher Enterprise</h3>
              <p className="text-blue-100">Innovating at the intersection of technology and sustainability</p>
            </div>

            <div className="space-y-4 pt-6 border-t border-blue-400">
              <div>
                <p className="text-sm font-semibold text-blue-100 uppercase tracking-wide mb-2">Focus Areas</p>
                <ul className="space-y-2 text-sm text-blue-50">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-300 rounded-full"></span>
                    Electric Vehicles & Sustainable Mobility
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-300 rounded-full"></span>
                    STEM Education & Learning Technology
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-300 rounded-full"></span>
                    AI & Machine Learning Solutions
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-300 rounded-full"></span>
                    Advanced Research & Development
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-slate-900 text-white px-6 py-12">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Zypher Enterprise
              </h4>
              <p className="text-sm text-slate-400">Pioneering innovation in technology and sustainability</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <a href="#about" className="hover:text-white transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="#expertise" className="hover:text-white transition-colors">
                    Expertise
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact Info</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li>
                  <a href="mailto:hamid@zypherenterprise.com" className="hover:text-white transition-colors">
                    Email
                  </a>
                </li>
                <li>
                  <a href="tel:+923367239339" className="hover:text-white transition-colors">
                    +92 336 7239339
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-700 pt-8 text-center text-sm text-slate-400">
            <p>© 2025 Engr Hamid Mehmood Afridi. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
